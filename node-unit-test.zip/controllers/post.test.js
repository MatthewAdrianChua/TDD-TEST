import { addPost } from "./postController";
import { jest } from "@jest/globals";